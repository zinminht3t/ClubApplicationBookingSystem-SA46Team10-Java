package com.example.android.getbookingandroid;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Locale;
import java.util.TimeZone;

public class ConfirmationActivity extends AppCompatActivity {

    private TextView dateTextView, timeslotTextView, facilityTextView, facilityTypeTextView;
    private Button buttonOK;

    private int userid;
    private String price;
    String FinalJSonObject;

    private int bookingid;
    private String facilityid;
    private String timeslotid;
    private String bookingDate;
    private String bookingidStr;
    private String selectedTimeSlot;

    String HttpURL = "http://172.17.248.239/SpringClub/addBooking.php";
    String HttpURL2 = "http://172.17.248.239/SpringClub/getBookingID.php";
    String HttpURL3 = "http://172.17.248.239/SpringClub/addBookingDetails.php";
    String ParseResult;

    String finalResult;
    String finalResult3;
    HashMap<String,String> hashMap = new HashMap<>();
    HashMap<String,String> ResultHash = new HashMap<>();
    HashMap<String,String> hashMap3 = new HashMap<>();
    HttpParse httpParse = new HttpParse();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_confirmation);

        dateTextView = findViewById(R.id.textView_confirmation_date);
        timeslotTextView = findViewById(R.id.textView_confirmation_timeslot);
        facilityTextView = findViewById(R.id.textView_confirmation_facility);
        facilityTypeTextView = findViewById(R.id.textView_confirmation_facility_type);

        Intent data = getIntent();
        dateTextView.setText(data.getStringExtra("CurrentDate"));
        timeslotTextView.setText(data.getStringExtra("Timeslot"));
        facilityTextView.setText(data.getStringExtra("Facility"));
        facilityTypeTextView.setText(data.getStringExtra("FacilityType"));

        userid = data.getIntExtra("userid", 0);
        String useridStr = String.valueOf(userid);

        buttonOK = findViewById(R.id.button_confirmation_ok);
        buttonOK.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), BookingActivity.class);
                intent.putExtra("userid", userid);
                intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                startActivity(intent);
            }
        });


        TimeZone timeZone = TimeZone.getTimeZone("GMT+8:00");
        Date currDate = new Date();
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        sdf.setTimeZone(timeZone);
        String currentDateString = sdf.format(currDate);

        price = data.getStringExtra("FacilityPrice");
        String status = "CONFIRMED";

        AddBooking(currentDateString, useridStr, price, status);
        facilityid = data.getStringExtra("FacilityId");

        selectedTimeSlot = data.getStringExtra("Timeslot");

        if (selectedTimeSlot.equals("9AM - 10AM"))
            timeslotid = "1";
        else if (selectedTimeSlot.equals("10AM - 11AM"))
            timeslotid = "2";
        else if (selectedTimeSlot.equals("11AM - 12PM"))
            timeslotid = "3";
        else if (selectedTimeSlot.equals("12PM - 1PM"))
            timeslotid = "4";
        else if (selectedTimeSlot.equals("1PM - 2PM"))
            timeslotid = "5";
        else if (selectedTimeSlot.equals("2PM - 3PM"))
            timeslotid = "6";
        else if (selectedTimeSlot.equals("3PM - 4PM"))
            timeslotid = "7";
        else if (selectedTimeSlot.equals("4PM - 5PM"))
            timeslotid = "8";
        else if (selectedTimeSlot.equals("5PM - 6PM"))
            timeslotid = "9";
        else if (selectedTimeSlot.equals("6PM - 7PM"))
            timeslotid = "10";
        else if (selectedTimeSlot.equals("7PM - 8PM"))
            timeslotid = "11";
        else if (selectedTimeSlot.equals("8PM - 9PM"))
            timeslotid = "12";

        bookingDate = data.getStringExtra("BookingDate");

        HttpWebCall();

    }

    @Override
    public void onBackPressed() {

        Intent intent = new Intent(getApplicationContext(), BookingActivity.class);
        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
        startActivity(intent);

//        super.onBackPressed();
    }

    public void AddBooking(final String currDateSelected, final String useridSelected, final String priceSelected, final String statusCfm){

        class AddBookingClass extends AsyncTask<String,Void,String> {

            @Override
            protected void onPreExecute() {
                super.onPreExecute();
            }

            @Override
            protected void onPostExecute(String httpResponseMsg) {

                super.onPostExecute(httpResponseMsg);
            }

            @Override
            protected String doInBackground(String... params) {

                hashMap.put("selectedDate",params[0]);

                hashMap.put("selectedUserid",params[1]);

                hashMap.put("selectedTotal",params[2]);

                hashMap.put("selectedStatus",params[3]);

                finalResult = httpParse.postRequest(hashMap, HttpURL);

                return finalResult;
            }
        }

        AddBookingClass addBookingClass = new AddBookingClass();

        addBookingClass.execute(currDateSelected, useridSelected, priceSelected, statusCfm);
    }

    //Method to show current record Current Selected Record
    public void HttpWebCall(){


        class HttpWebCallFunction extends AsyncTask<String,Void,String> {

            @Override
            protected void onPreExecute() {
                super.onPreExecute();
            }

            @Override
            protected void onPostExecute(String httpResponseMsg) {

                super.onPostExecute(httpResponseMsg);

                //Storing Complete JSon Object into String Variable.
                FinalJSonObject = httpResponseMsg ;

                //Parsing the Stored JSOn String to GetHttpResponse Method.
                new GetHttpResponse(ConfirmationActivity.this).execute();

            }

            @Override
            protected String doInBackground(String... params) {

                ParseResult = httpParse.postRequest(ResultHash, HttpURL2);
                return ParseResult;
            }
        }

        HttpWebCallFunction httpWebCallFunction = new HttpWebCallFunction();

        httpWebCallFunction.execute();


    }

    // Parsing Complete JSON Object.
    private class GetHttpResponse extends AsyncTask<Void, Void, Void>
    {
        public Context context;

        public GetHttpResponse(Context context)
        {
            this.context = context;
        }

        @Override
        protected void onPreExecute()
        {
            super.onPreExecute();
        }

        @Override
        protected Void doInBackground(Void... arg0)
        {
            try
            {
                if(FinalJSonObject != null)
                {
                    JSONArray jsonArray = null;

                    try {
                        jsonArray = new JSONArray(FinalJSonObject);

                        JSONObject jsonObject;

                        for(int i=jsonArray.length()-1; i<jsonArray.length(); i++)
                        {
                            jsonObject = jsonArray.getJSONObject(i);

                            bookingid = jsonObject.getInt("bookingid");


                        }
                    }
                    catch (JSONException e) {
                        // TODO Auto-generated catch block
                        e.printStackTrace();
                    }
                }
            }
            catch (Exception e)
            {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }
            return null;
        }

        @Override
        protected void onPostExecute(Void result)
        {
            bookingidStr = String.valueOf(bookingid);


            AddBookingDetails(bookingidStr, facilityid, timeslotid, bookingDate, price);


        }
    }

    public void AddBookingDetails(final String currBookingIDSelected, final String facilityidSelected, final String timeslotidSelected, final String bookingDateSelected, final String bookingPriceSelected){

        class AddBookingDetailsClass extends AsyncTask<String,Void,String> {

            @Override
            protected void onPreExecute() {
                super.onPreExecute();
            }

            @Override
            protected void onPostExecute(String httpResponseMsg) {

                super.onPostExecute(httpResponseMsg);
            }

            @Override
            protected String doInBackground(String... params) {

                hashMap3.put("selectedBookingid",params[0]);

                hashMap3.put("selectedFacilityid",params[1]);

                hashMap3.put("selectedTimeslotid",params[2]);

                hashMap3.put("selectedBookingDate",params[3]);

                hashMap3.put("selectedBookingPrice",params[4]);

                finalResult3 = httpParse.postRequest(hashMap3, HttpURL3);

                return finalResult3;
            }
        }

        AddBookingDetailsClass addBookingDetailsClass = new AddBookingDetailsClass();

        addBookingDetailsClass.execute(currBookingIDSelected, facilityidSelected, timeslotidSelected, bookingDateSelected, bookingPriceSelected);
    }














}
