package com.example.android.getbookingandroid;

import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.AsyncTask;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class LoginActivity extends AppCompatActivity {

    HttpParse httpParse = new HttpParse();
    String HttpUrl = "http://172.17.248.239/SpringClub/allLogin.php";

    private Button buttonLogin;
    HashMap<String,String> ResultHash = new HashMap<>();
    HashMap<String,Integer> ResultHashID = new HashMap<>();

    private EditText usernameEditText;
    private EditText passwordEditText;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        setTitle("Login");

        new LoginActivity.GetHttpResponse(LoginActivity.this).execute();

        buttonLogin = findViewById(R.id.button_login);

        usernameEditText = findViewById(R.id.editText_login);
        passwordEditText = findViewById(R.id.editText_password);


        buttonLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String correctPassword = ResultHash.get(usernameEditText.getText().toString());

                if(ResultHashID.get(usernameEditText.getText().toString()) == null){

                    AlertDialog.Builder builder = new AlertDialog.Builder(v.getContext());
                    builder.setMessage(R.string.error_username);
                    builder.setPositiveButton(R.string.dialog_ok, new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            if (dialog != null){
                                dialog.dismiss();
                            }
                        }
                    });

                    AlertDialog alertDialog = builder.create();
                    alertDialog.show();

                    return;
                }

                int userid = ResultHashID.get(usernameEditText.getText().toString());

                if (passwordEditText.getText().toString().equals(correctPassword)){
                    Intent i = new Intent(getApplicationContext(), BookingActivity.class);
                    i.putExtra("userid", userid);
                    startActivity(i);
                    finish();
                } else{

                    AlertDialog.Builder builder = new AlertDialog.Builder(v.getContext());
                    builder.setMessage(R.string.dialog_error);
                    builder.setPositiveButton(R.string.dialog_ok, new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            if (dialog != null){
                                dialog.dismiss();
                            }
                        }
                    });

                    AlertDialog alertDialog = builder.create();
                    alertDialog.show();

                }


            }
        });


    }


    // JSON parse class started from here.
    private class GetHttpResponse extends AsyncTask<Void, Void, Void>
    {
        public Context context;

        String JSonResult;

        public GetHttpResponse(Context context)
        {
            this.context = context;
        }

        @Override
        protected void onPreExecute()
        {
            super.onPreExecute();
        }

        @Override
        protected Void doInBackground(Void... arg0)
        {
            // Passing HTTP URL to HttpServicesClass Class.
            HttpServicesClass httpServicesClass = new HttpServicesClass(HttpUrl);
            try
            {
                httpServicesClass.ExecutePostRequest();

                if(httpServicesClass.getResponseCode() == 200)
                {
                    JSonResult = httpServicesClass.getResponse();

                    if(JSonResult != null)
                    {
                        JSONArray jsonArray = null;

                        try {
                            jsonArray = new JSONArray(JSonResult);

                            JSONObject jsonObject;

                            for(int i=0; i<jsonArray.length(); i++)
                            {

                                jsonObject = jsonArray.getJSONObject(i);
                                String username = jsonObject.getString("email").toString();
                                String password = jsonObject.getString("password").toString();
                                Integer userid = jsonObject.getInt("userid");

                                ResultHash.put(username, password);
                                ResultHashID.put(username, userid);

                            }
                        }
                        catch (JSONException e) {
                            // TODO Auto-generated catch block
                            e.printStackTrace();
                        }
                    }
                }
                else
                {
                    Toast.makeText(context, httpServicesClass.getErrorMessage(), Toast.LENGTH_SHORT).show();
                }
            }
            catch (Exception e)
            {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }
            return null;
        }

        @Override
        protected void onPostExecute(Void result)
        {

        }


    }

























}
