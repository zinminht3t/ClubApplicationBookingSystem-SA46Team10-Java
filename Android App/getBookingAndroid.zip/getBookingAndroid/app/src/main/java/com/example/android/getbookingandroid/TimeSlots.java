package com.example.android.getbookingandroid;

public class TimeSlots {

    int timeSlotsId;
    String timeSlotsTiming;
    String timeSlotsAvailability;

    public TimeSlots(int timeSlotsId, String timeSlotsTiming, String timeSlotsAvailability){
        this.timeSlotsId = timeSlotsId;
        this.timeSlotsTiming = timeSlotsTiming;
        this.timeSlotsAvailability = timeSlotsAvailability;
    }

    public int getTimeSlotsId() {
        return timeSlotsId;
    }

    public String getTimeSlotsTiming() {
        return timeSlotsTiming;
    }

    public String getTimeSlotsAvailability() {
        return timeSlotsAvailability;
    }

}
