package com.example.android.getbookingandroid;

import android.content.Context;
import android.content.Intent;
import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ProgressBar;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class BookingActivity extends AppCompatActivity {

    private ArrayAdapter<String> facilityAdapter;
    private ArrayAdapter<String> facilityTypeAdapter;

    private Spinner mFacilitySpinner;
    private Spinner mFacilityTypeSpinner;

    private TextView textViewPrice;
    private TextView textViewId;

    private Button mButtonNext;

    HttpParse httpParse = new HttpParse();
    String HttpUrl = "http://172.17.248.239/SpringClub/allFacilities.php";

    List<String> facilityList;
    List<String> facilityTypeList;
    List<Facilities> allInfoFacilities;


    HashMap<String, List<String>> facilityListMap;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_booking);

        setTitle("Facilities");

        mFacilitySpinner = findViewById(R.id.spinner_facility);
        mFacilityTypeSpinner = findViewById(R.id.spinner_facility_type);
        textViewId = findViewById(R.id.booking_facility_id_value);
        textViewPrice = findViewById(R.id.booking_facility_price_value);

        new GetHttpResponse(BookingActivity.this).execute();

        mButtonNext = findViewById(R.id.button_booking_next);
        mButtonNext.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(getApplicationContext(), CalendarViewActivity.class);
                i.putExtra("Facility", mFacilitySpinner.getSelectedItem().toString());
                i.putExtra("FacilityType", mFacilityTypeSpinner.getSelectedItem().toString());
                i.putExtra("FacilityId", textViewId.getText());
                i.putExtra("FacilityPrice", textViewPrice.getText());
                i.putExtra("userid", getIntent().getIntExtra("userid", 0));
                startActivity(i);
            }
        });

    }

    //Setup the Spinner
    private void setupSpinner(){
        facilityAdapter = new ArrayAdapter<String>(BookingActivity.this, android.R.layout.simple_spinner_item, facilityList);
        facilityAdapter.setDropDownViewResource(android.R.layout.simple_dropdown_item_1line);
        mFacilitySpinner.setAdapter(facilityAdapter);

        mFacilitySpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                facilityTypeAdapter = new ArrayAdapter<String>(BookingActivity.this, android.R.layout.simple_spinner_item, facilityListMap.get(mFacilitySpinner.getSelectedItem().toString()));
                facilityTypeAdapter.setDropDownViewResource(android.R.layout.simple_dropdown_item_1line);
                mFacilityTypeSpinner.setAdapter(facilityTypeAdapter);

                for (Facilities f: allInfoFacilities) {
                    if (f.getFacilityName().equals(mFacilitySpinner.getSelectedItem().toString()) && f.getCourt().equals(mFacilityTypeSpinner.getSelectedItem().toString())){

                        NumberFormat formatter = new DecimalFormat("#,##0.00");

                        textViewId.setText("" + f.getFacilityId());
                        textViewPrice.setText("" + formatter.format(f.getPrice()));
                    }
                }

            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
                //Intentionally left empty
            }
        });

        mFacilityTypeSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                for (Facilities f: allInfoFacilities) {
                    if (f.getFacilityName().equals(mFacilitySpinner.getSelectedItem().toString()) && f.getCourt().equals(mFacilityTypeSpinner.getSelectedItem().toString())){

                        NumberFormat formatter = new DecimalFormat("#,##0.00");

                        textViewId.setText("" + f.getFacilityId());
                        textViewPrice.setText("" + formatter.format(f.getPrice()));
                    }
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });
    }


    // JSON parse class started from here.
    private class GetHttpResponse extends AsyncTask<Void, Void, Void>
    {
        public Context context;

        String JSonResult;

        public GetHttpResponse(Context context)
        {
            this.context = context;
        }

        @Override
        protected void onPreExecute()
        {
            super.onPreExecute();
        }

        @Override
        protected Void doInBackground(Void... arg0)
        {
            // Passing HTTP URL to HttpServicesClass Class.
            HttpServicesClass httpServicesClass = new HttpServicesClass(HttpUrl);
            try
            {
                httpServicesClass.ExecutePostRequest();

                if(httpServicesClass.getResponseCode() == 200)
                {
                    JSonResult = httpServicesClass.getResponse();

                    if(JSonResult != null)
                    {
                        JSONArray jsonArray = null;

                        try {
                            jsonArray = new JSONArray(JSonResult);

                            JSONObject jsonObject;

                            facilityList = new ArrayList<String>();
                            facilityListMap = new HashMap<String, List<String>>();
                            allInfoFacilities = new ArrayList<Facilities>();

                            for(int i=0; i<jsonArray.length(); i++)
                            {
                                Facilities newFacility = new Facilities();
                                jsonObject = jsonArray.getJSONObject(i);
                                List<String> facilityTypeList = facilityListMap.get(jsonObject.getString("facilityname").toString());

                                if(jsonObject.getInt("active") != 1){
                                    continue;
                                }

                                if (facilityTypeList == null){
                                    facilityTypeList = new ArrayList<String>();
                                    facilityListMap.put(jsonObject.getString("facilityname").toString(), facilityTypeList);
                                }

                                boolean duplicateFacility = false;

                                for(String s: facilityList){
                                    if (s.equals(jsonObject.getString("facilityname").toString())){
                                        duplicateFacility = true;
                                    }
                                }

                                if (!duplicateFacility){
                                    facilityList.add(jsonObject.getString("facilityname").toString());
                                }

                                facilityTypeList.add(jsonObject.getString("court").toString());
                                facilityListMap.put(jsonObject.getString("facilityname").toString(), facilityTypeList);

                                newFacility.setFacilityId(jsonObject.getInt("facilityid"));
                                newFacility.setFacilityName(jsonObject.getString("facilityname").toString());
                                newFacility.setCourt(jsonObject.getString("court").toString());
                                newFacility.setPrice(jsonObject.getDouble("price"));
                                allInfoFacilities.add(newFacility);

                            }
                        }
                        catch (JSONException e) {
                            // TODO Auto-generated catch block
                            e.printStackTrace();
                        }
                    }
                }
                else
                {
                    Toast.makeText(context, httpServicesClass.getErrorMessage(), Toast.LENGTH_SHORT).show();
                }
            }
            catch (Exception e)
            {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }
            return null;
        }

        @Override
        protected void onPostExecute(Void result)
        {
            setupSpinner();
        }
    }


}
