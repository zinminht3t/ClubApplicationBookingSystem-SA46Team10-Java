package com.example.android.getbookingandroid;

import android.content.Context;
import android.content.Intent;
import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.List;

public class TimeSlotsActivity extends AppCompatActivity {

    String currentDateString;
    String dateStringConfirmation;
    TimeSlotsListAdapter adapter;

    HttpParse httpParse = new HttpParse();
    String HttpURL = "http://172.17.248.239/SpringClub/getTimeslots.php";
    String FinalJSonObject;
    int dataFacilityId;
    String dataBookingDate;
    double dataBookingPrice;

    List<Integer> dataTimeslots = new ArrayList<Integer>();

    List<Integer> maintenanceStartID = new ArrayList<Integer>();
    List<Integer> maintenanceEndID = new ArrayList<Integer>();
    List<String> maintenanceStartDate = new ArrayList<String>();
    List<String> maintenanceEndDate = new ArrayList<String>();
    List<Integer> maintenanceActive = new ArrayList<Integer>();

    List<Integer> maintenanceTimeSlots = new ArrayList<Integer>();

    HashMap<String,String> ResultHash = new HashMap<>();
    String ParseResult;
    private RecyclerView mRecyclerViewTimeSlots;
    private List<TimeSlots> timeSlotsList;
    private int dayOfMonth, month, year;
    private String facility;
    private String facilityType;
    private int userid;
    private String priceStr;
    private double price;

    private String facilityId;
    private String facilityPrice;

    Date dateSelected;
    Date maintenanceStartDateDatefmt;
    Date maintenanceEndDateDatefmt;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_time_slots);

        Intent data = getIntent();
        dayOfMonth = data.getIntExtra("Day", 0);
        month = data.getIntExtra("Month", 0);
        year = data.getIntExtra("Year", 0);

        facility = data.getStringExtra("Facility");
        facilityType = data.getStringExtra("FacilityType");

        facilityId = data.getStringExtra("FacilityId");
        facilityPrice = data.getStringExtra("FacilityPrice");

        userid = data.getIntExtra("userid", 0);
        priceStr = data.getStringExtra("FacilityPrice");
        price = Double.parseDouble(priceStr);

        Calendar cal = new GregorianCalendar(year, month, dayOfMonth);
        Date currentDate = cal.getTime();

        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        currentDateString = sdf.format(currentDate);

        SimpleDateFormat sdf1 = new SimpleDateFormat("dd MMM yyyy");
        dateStringConfirmation = sdf1.format(currentDate);

        setTitle(dateStringConfirmation);


        mRecyclerViewTimeSlots = findViewById(R.id.recyclerview_timeslots_activity);
        timeSlotsList = new ArrayList<TimeSlots>();

        timeSlotsList.add(new TimeSlots(1, "9AM - 10AM", ""));
        timeSlotsList.add(new TimeSlots(2, "10AM - 11AM", ""));
        timeSlotsList.add(new TimeSlots(3, "11AM - 12PM", ""));
        timeSlotsList.add(new TimeSlots(4, "12PM - 1PM", ""));
        timeSlotsList.add(new TimeSlots(5, "1PM - 2PM", ""));
        timeSlotsList.add(new TimeSlots(6, "2PM - 3PM", ""));
        timeSlotsList.add(new TimeSlots(7, "3PM - 4PM", ""));
        timeSlotsList.add(new TimeSlots(8, "4PM - 5PM", ""));
        timeSlotsList.add(new TimeSlots(9, "5PM - 6PM", ""));
        timeSlotsList.add(new TimeSlots(10, "6PM - 7PM", ""));
        timeSlotsList.add(new TimeSlots(11, "7PM - 8PM", ""));
        timeSlotsList.add(new TimeSlots(12, "8PM - 9PM", ""));

        HttpWebCall(currentDateString, facilityId);

        adapter = new TimeSlotsListAdapter(this, timeSlotsList, facility, facilityType, dateStringConfirmation, userid, priceStr, facilityId, currentDateString);

        mRecyclerViewTimeSlots.setAdapter(adapter);
        mRecyclerViewTimeSlots.setLayoutManager(new LinearLayoutManager(this));

        String dateStr = currentDateString;

        dateSelected = new Date();
        try {
            dateSelected = new SimpleDateFormat("yyyy-MM-dd").parse(dateStr);
        } catch (ParseException e) {
            e.printStackTrace();
        }

        maintenanceStartDateDatefmt = new Date();
        maintenanceEndDateDatefmt = new Date();

    }


    //Method to show current record Current Selected Record
    public void HttpWebCall(final String selectedDateCal, String selectedFacilityId){


        class HttpWebCallFunction extends AsyncTask<String,Void,String> {

            @Override
            protected void onPreExecute() {
                super.onPreExecute();
            }

            @Override
            protected void onPostExecute(String httpResponseMsg) {

                super.onPostExecute(httpResponseMsg);

                //Storing Complete JSon Object into String Variable.
                FinalJSonObject = httpResponseMsg ;

                //Parsing the Stored JSOn String to GetHttpResponse Method.
                new GetHttpResponse(TimeSlotsActivity.this).execute();

            }

            @Override
            protected String doInBackground(String... params) {

                ResultHash.put("selectedDate",params[0]);
                ResultHash.put("selectedFacilityId",params[1]);

                ParseResult = httpParse.postRequest(ResultHash, HttpURL);
                return ParseResult;
            }
        }

        HttpWebCallFunction httpWebCallFunction = new HttpWebCallFunction();

        httpWebCallFunction.execute(selectedDateCal, selectedFacilityId);


    }

    // Parsing Complete JSON Object.
    private class GetHttpResponse extends AsyncTask<Void, Void, Void>
    {
        public Context context;

        public GetHttpResponse(Context context)
        {
            this.context = context;
        }

        @Override
        protected void onPreExecute()
        {
            super.onPreExecute();
        }

        @Override
        protected Void doInBackground(Void... arg0)
        {
            try
            {
                if(FinalJSonObject != null)
                {
                    JSONArray jsonArray = null;

                    try {
                        jsonArray = new JSONArray(FinalJSonObject);

                        JSONObject jsonObject;

                        for(int i=0; i<jsonArray.length(); i++)
                        {
                            jsonObject = jsonArray.getJSONObject(i);

                            dataFacilityId = jsonObject.getInt("facilityid");
                            dataBookingPrice = jsonObject.getDouble("bookingprice");
                            dataBookingDate = jsonObject.getString("bookingdate");

                            String dataFacilityIdStr = String.valueOf(dataFacilityId);

                            if (currentDateString.equals(dataBookingDate) && dataFacilityIdStr.equals(facilityId)){
                                dataTimeslots.add(jsonObject.getInt("timeslotid"));
                            }

                            maintenanceStartID.add(jsonObject.getInt("timestartid"));
                            maintenanceEndID.add(jsonObject.getInt("timeendid"));
                            maintenanceStartDate.add(jsonObject.getString("startdate"));
                            maintenanceEndDate.add(jsonObject.getString("enddate"));
                            maintenanceActive.add(jsonObject.getInt("active"));


                        }
                    }
                    catch (JSONException e) {
                        e.printStackTrace();
                    }
                }
            }
            catch (Exception e)
            {
                e.printStackTrace();
            }
            return null;
        }

        @Override
        protected void onPostExecute(Void result)
        {
            //Check bookings
            for(int i = 0; i < adapter.mTimeSlots.size(); i++){

                boolean booked = false;

                for(int j = 0; j < dataTimeslots.size(); j++){
                    if (adapter.mTimeSlots.get(i).getTimeSlotsId() == (dataTimeslots.get(j))){
                        adapter.mTimeSlots.get(i).timeSlotsAvailability = "Not Available";
                        booked = true;
                    }
                }

                if (!booked)
                    adapter.mTimeSlots.get(i).timeSlotsAvailability = "Available";
            }

            //Check maintenances


            for(int i = 0; i < maintenanceStartID.size(); i++){

                if (maintenanceActive.get(i) != 1){
                    continue;
                }

                try {
                    maintenanceStartDateDatefmt = new SimpleDateFormat("yyyy-MM-dd").parse(maintenanceStartDate.get(i));
                } catch (ParseException e) {
                    e.printStackTrace();
                }

                try {
                    maintenanceEndDateDatefmt = new SimpleDateFormat("yyyy-MM-dd").parse(maintenanceEndDate.get(i));
                } catch (ParseException e) {
                    e.printStackTrace();
                }

                if (maintenanceStartDate.get(i).equals(maintenanceEndDate.get(i)) && maintenanceStartDate.get(i).equals(currentDateString)){

                    for (int j = maintenanceStartID.get(i); j <= maintenanceEndID.get(i); j++){
                        maintenanceTimeSlots.add(j);
                    }

                }
                else if(!maintenanceStartDate.get(i).equals(maintenanceEndDate.get(i)) && maintenanceStartDate.get(i).equals(currentDateString)){
                    for (int j = maintenanceStartID.get(i); j <= 12; j++){
                        maintenanceTimeSlots.add(j);
                    }
                }
                else if(!maintenanceStartDate.get(i).equals(maintenanceEndDate.get(i)) && maintenanceEndDate.get(i).equals(currentDateString)){
                    for (int j = maintenanceEndID.get(i); j >0; j--){
                        maintenanceTimeSlots.add(j);
                    }
                }
                else if(dateSelected.after(maintenanceStartDateDatefmt) && dateSelected.before(maintenanceEndDateDatefmt)){
                    for (int j = 1; j <= 12; j++){
                        maintenanceTimeSlots.add(j);
                    }
                }

            }

            for(int i = 0; i < adapter.mTimeSlots.size(); i++){

                for(int j = 0; j < maintenanceTimeSlots.size(); j++){
                    if (adapter.mTimeSlots.get(i).getTimeSlotsId() == (maintenanceTimeSlots.get(j))){
                        adapter.mTimeSlots.get(i).timeSlotsAvailability = "Not Available";
                    }
                }

            }

            adapter.notifyDataSetChanged();
        }
    }


}
