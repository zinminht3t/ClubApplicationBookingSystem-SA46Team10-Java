package com.example.android.getbookingandroid;

import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.CalendarView;
import android.widget.Toast;

public class CalendarViewActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_calendar_view);

        CalendarView calendarView = findViewById(R.id.calendarView);
        calendarView.setOnDateChangeListener(new CalendarView.OnDateChangeListener() {
            @Override
            public void onSelectedDayChange(@NonNull CalendarView view, int year, int month, int dayOfMonth) {
                Intent replyIntent = getIntent();

                Intent intent = new Intent(getApplicationContext(), TimeSlotsActivity.class);

                intent.putExtra("Facility", replyIntent.getStringExtra("Facility"));
                intent.putExtra("FacilityType", replyIntent.getStringExtra("FacilityType"));
                intent.putExtra("Year", year);
                intent.putExtra("Month", month);
                intent.putExtra("Day", dayOfMonth);
                intent.putExtra("FacilityId", replyIntent.getStringExtra("FacilityId"));
                intent.putExtra("FacilityPrice", replyIntent.getStringExtra("FacilityPrice"));
                intent.putExtra("userid", getIntent().getIntExtra("userid", 0));
                startActivity(intent);
            }
        });

    }
}
