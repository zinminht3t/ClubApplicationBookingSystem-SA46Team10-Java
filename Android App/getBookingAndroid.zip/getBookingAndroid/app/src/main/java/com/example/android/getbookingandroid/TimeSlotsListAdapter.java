package com.example.android.getbookingandroid;

import android.app.Activity;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Color;
import android.support.annotation.NonNull;
import android.support.v7.app.AlertDialog;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RelativeLayout;
import android.widget.TextView;

import java.util.List;

public class TimeSlotsListAdapter
        extends RecyclerView.Adapter<TimeSlotsListAdapter.TimeSlotsViewHolder>{

    private final LayoutInflater mInflater;
    List<TimeSlots> mTimeSlots; //Cached copy of timeslots
    private String facility;
    private String facilityType;
    private String selectedDate;
    private int userid;
    private String price;
    private String facilityid;
    private String dateStringDb;

    class TimeSlotsViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener{

        private TextView timeslotsView;
        private TextView timeslotsAvailability;

        private TimeSlotsViewHolder(View itemView){
            super(itemView);

            timeslotsView = itemView.findViewById(R.id.textView_timeslots);
            timeslotsAvailability = itemView.findViewById(R.id.textView_timeslots_availability);
            itemView.setOnClickListener(this);
        }

        @Override
        public void onClick(View v) {

            //To check if the slot is already taken
            TextView text_view_timeslots_availability = v.findViewById(R.id.textView_timeslots_availability);
            if (text_view_timeslots_availability.getText().toString().equals("Not Available")){

                AlertDialog.Builder builder = new AlertDialog.Builder(v.getContext());
                builder.setMessage(R.string.dialog_slot_not_available);
                builder.setPositiveButton(R.string.dialog_ok, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        if (dialog != null){
                            dialog.dismiss();
                        }
                    }
                });

                AlertDialog alertDialog = builder.create();
                alertDialog.show();
            }

            else{

                final Context ctx = v.getContext();

                AlertDialog.Builder builder = new AlertDialog.Builder(v.getContext());
                builder.setMessage(R.string.dialog_confirm_booking);
                builder.setPositiveButton(R.string.dialog_yes, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        Intent intent = new Intent(ctx, ConfirmationActivity.class);
                        intent.putExtra("CurrentDate", selectedDate);
                        intent.putExtra("Timeslot", timeslotsView.getText());
                        intent.putExtra("Facility", facility);
                        intent.putExtra("FacilityType", facilityType);
                        intent.putExtra("userid", userid);
                        intent.putExtra("FacilityPrice", price);
                        intent.putExtra("FacilityId", facilityid);
                        intent.putExtra("BookingDate", dateStringDb);
                        ((Activity) ctx).startActivity(intent);
                    }
                });
                builder.setNegativeButton(R.string.dialog_no, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        if (dialog != null){
                            dialog.dismiss();
                        }
                    }
                });

                AlertDialog alertDialog = builder.create();
                alertDialog.show();

            }

        }
    }

    TimeSlotsListAdapter(Context context, List<TimeSlots> timeSlots, String facility, String facilityType, String selectedDate, int userid, String price, String facilityid, String dateStringDb){
        mInflater = LayoutInflater.from(context);
        mTimeSlots = timeSlots;
        this.facility = facility;
        this.facilityType = facilityType;
        this.selectedDate = selectedDate;
        this.userid = userid;
        this.price = price;
        this.facilityid = facilityid;
        this.dateStringDb = dateStringDb;
    }

    @NonNull
    @Override
    public TimeSlotsViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View itemView = mInflater.inflate(R.layout.recyclerview_timeslots, parent, false);
        return new TimeSlotsViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(@NonNull TimeSlotsViewHolder holder, int position) {

        TimeSlots current = mTimeSlots.get(position);
        holder.timeslotsView.setText(current.getTimeSlotsTiming());
        holder.timeslotsAvailability.setText(current.getTimeSlotsAvailability());

        if (current.getTimeSlotsAvailability().equals("Not Available")){
            holder.timeslotsAvailability.setTextColor(Color.RED);
        }


    }

    @Override
    public int getItemCount() {
        if (mTimeSlots != null)
            return mTimeSlots.size();
        else return 0;
    }


}

